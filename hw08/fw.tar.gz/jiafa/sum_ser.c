#include <stdio.h>
#include <malloc.h>
#include <time.h>

int main(){
	long long N = 5000000000;
	clock_t start, end;
	long long i,j = 0;
	long double sum = 0;
	long double k;
	long long* a = NULL;
	start = clock();
	for(j=0;j<2;j++){
		a = (long long *)malloc(sizeof(long long)*N);
		for(i=0;i<N;i++){
			a[i] = j*N+i+1;
		}
		printf("%ld\n",a[i-1]);	
		for(i=0;i<N-2;i++){
		sum +=(a[i]+a[i+1]+a[i+2]);		
		}
		if(j==0)
			sum += a[N-2] + 2*a[N-1];
		else
			sum += 2*a[0] + a[1];
		free(a); 
		a=NULL;
	}
	k = sum/2.0;
	end = clock();
	printf("k=%llf\t%f\n",k,(double)(end-start)/CLOCKS_PER_SEC);
	return 0;
}


