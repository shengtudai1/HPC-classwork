#include <stdio.h>
#include "mpi.h"
#include <malloc.h>
//#include "omp.h"
int main(int argc, char* argv[]){
	long long N = 5000000000;
	double start, end;// start1, end1;
	long long i,j = 0;
	long double sum[2] = {0.0,0.0};
	long double b = 0.0;
	long double sum_1 = 0.0;
	long double redu = 0;
	long double k;
	long long* a = NULL;
	MPI_Init(&argc,&argv);
	int world_rank, world_size;
	MPI_Comm_rank(MPI_COMM_WORLD,&world_rank);
	MPI_Comm_size(MPI_COMM_WORLD,&world_size);
	start = MPI_Wtime();
	long long step = N/world_size;
	printf("step=%ld\n",step);
	for(j=0;j<2;j++){
		a = (long long *)malloc(sizeof(long long)*step);
		int id = world_rank;
		//#pragma omp parallel for
		for(i=0;i<step;i++)
			a[i] = j*N + id*step + i+1;
		
		printf("第%d个进程，第%d次\n",id,j);
		b = 0.0;
		//#pragma omp parallel for reduction(+:b)
		for(i=0;i<step-2;i++){
			b +=(a[i]+a[i+1]+a[i+2]);}
		sum[j] = b;
		printf("%llf\n",sum[j]);	
	
		if(j==0&&id==0)
			sum[j] += a[step-2] + 2*a[step-1];
		else if(j==1&&id==(world_size-1))
			sum[j] += 2*a[0] + a[1];
		else
			sum[j] += a[step-2] + 2*a[step-1] + 2*a[0] + a[1];
		free(a); 
		a=NULL;
	}
	sum_1 = sum[0] + sum[1];
	MPI_Reduce(&sum_1,&redu,1,MPI_LONG_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
	MPI_Barrier(MPI_COMM_WORLD);
	end = MPI_Wtime();
	if(world_rank==0)
		printf("%llf\t%llf\t%f\n",redu,redu/2.0,end-start);
	return MPI_Finalize();
}


