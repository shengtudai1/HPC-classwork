echo "Bcast"
./broadcast.sh
cat broadcast
echo "Gather"
./gather.sh
cat gather
echo "Reduce"
./reduce.sh
cat reduce 
